class CreateStudents < ActiveRecord::Migration[7.0]
  def change
    create_table :students do |t|
      t.string :surname
      t.string :name
      t.datetime :birth
      t.string :classroom

      t.timestamps
    end
  end
end
